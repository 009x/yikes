Bot made by me (divinity (@x32u))

A more up to date of Cop's leak on Evict.


Old version of Evict using Pretend (sents) base. 